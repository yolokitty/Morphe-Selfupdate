Tabler Icons for the Morphe 'Player icon style' patch option.

Select this zip file in the 'Custom icons' option of the 'Player icon style' patch,
then choose 'Custom' in the player icon style setting of the patched app.

Each file is named after the icon it replaces. Remove any file to keep the
'Automatic' style for that icon, or replace a file with your own vector drawable.

Icons: https://github.com/tabler/tabler-icons/tree/0239805680a36bab4e1070529b6744924402d804 (MIT, see LICENSE)
