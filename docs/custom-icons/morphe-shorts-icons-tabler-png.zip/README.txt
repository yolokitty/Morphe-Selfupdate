Tabler Icons as PNG images for the Morphe 'Custom icons' patch option.

The same icons as the vector pack, rendered white at 96x96 pixels.
The vector pack is sharper, this one shows that a pack can be made of PNG images.

Icons: https://github.com/tabler/tabler-icons/tree/0239805680a36bab4e1070529b6744924402d804 (MIT, see LICENSE)
